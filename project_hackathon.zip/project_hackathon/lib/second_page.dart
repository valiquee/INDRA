import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project_hackathon/TunarunguPage.dart';
import 'package:project_hackathon/TunawicaraPage.dart';

class SecondPage extends StatelessWidget {
  const SecondPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(


      body: Stack(
        children: [
          // Gambar atas
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Image.asset(
              'assets/atas.png',
              width: 400,
              height: 250,
              fit: BoxFit.cover,
            ),
          ),

          // Gambar bawah
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Image.asset(
              'assets/bawah.png',
              width: 400,
              height: 250,
              fit: BoxFit.cover,
            ),
          ),

          SafeArea(

            child: Padding(
              padding: const EdgeInsets.only(top: 100.0),
              child: Align(
                alignment: Alignment.topCenter,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Selamat Datang Di, INDRA!',
                      style: GoogleFonts.poppins(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF448376),
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Silakan klik menu ',
                      style: GoogleFonts.poppins(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF448376),
                      ),
                    ),
                    Text(
                      'yang ingin dituju',
                      style: GoogleFonts.poppins(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF448376),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Konten utama di tengah
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const TunawicaraPage())
                    );
                  },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF448376),
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  'Tunawicara',
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                      fontWeight: FontWeight.bold,
                    color: Colors.white
                  ),
                ),
                ),

                SizedBox(height: 30),
                
                ElevatedButton(
                  onPressed: (){
                    Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => TunarunguPage())
                    );
                  },
                style: ElevatedButton.styleFrom(
                  backgroundColor:  Color(0xFF448376),
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),

                child: Text(
                  'Tunarungu',
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                      fontWeight: FontWeight.bold,
                    color: Colors.white
                  ),
                ),
                ),
              ],
            ),
          ),

          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 30),
              child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },

                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    side: BorderSide(color: Color(0xFF448376), width: 2),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),

              child: Text(
                'Kembali Ke Halaman Utama',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF448376),
                ),
              ),
              ),
            ),
          ),
        ]
      ),
    );
  }
}