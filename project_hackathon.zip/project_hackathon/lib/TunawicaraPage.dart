import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project_hackathon/TunawicaraPage.dart';

class TunawicaraPage extends StatefulWidget {
  const TunawicaraPage({super.key});

  @override
  State<TunawicaraPage> createState() => _TunawicaraPageState();
}

class _TunawicaraPageState extends State<TunawicaraPage> {
  final FlutterTts flutterTts = FlutterTts();
  final TextEditingController _textController = TextEditingController();

  Future<void> _speak() async {
    String text = _textController.text;
    if (text.isNotEmpty) {
      await flutterTts.setLanguage("id-ID");
      await flutterTts.setPitch(1.0);
      await flutterTts.setSpeechRate(0.5);
      await flutterTts.speak(text);
    }
  }

  @override
  void dispose() {
    flutterTts.stop();
    _textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Gambar atas
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Image.asset(
              'assets/atas.png',
              height: 250,
              fit: BoxFit.cover,
            ),
          ),

          // Gambar bawah
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Image.asset(
              'assets/bawah.png',
              height: 250,
              fit: BoxFit.cover,
            ),
          ),

          // Konten Utama
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: 50.0, left: 24, right: 24),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Center(
                      child: Text(
                        'Menu Tunawicara',
                        style: GoogleFonts.poppins(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF448376),
                        ),
                      ),
                    ),

                    const SizedBox(height: 40),

                    Center(
                      child: Text(
                        'Text Menjadi Suara',
                        style: GoogleFonts.poppins(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF448376),
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),

                    TextField(
                      controller: _textController,
                      maxLines: 5,
                      style: GoogleFonts.poppins(fontSize: 16),
                      decoration: InputDecoration(
                        hintText: "Ketikkan teks di sini...",
                        hintStyle: GoogleFonts.poppins(color: Colors.grey),
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),

                    ElevatedButton.icon(
                      onPressed: _speak,
                      icon: const Icon(Icons.volume_up, color: Colors.white),
                      label: Text(
                        'Ubah Menjadi Suara',
                        style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Colors.white,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF448376),
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),

                    const SizedBox(height: 50),

                    ElevatedButton.icon(
                      onPressed: () {
                        showModalBottomSheet(
                          context: context,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                          ),
                          backgroundColor: Colors.white,
                          builder: (context) {
                            final quickPhrases = ['Iya', 'Tidak', 'Terima kasih', 'Maaf', 'Tolong', 'Selamat pagi', 'halo'];

                            return Padding(
                              padding: const EdgeInsets.all(20),
                              child: Wrap(
                                spacing: 12,
                                runSpacing: 12,
                                children: quickPhrases.map((phrase) {
                                  return ElevatedButton(
                                    onPressed: () {
                                      Navigator.pop(context);
                                      flutterTts.setLanguage("id-ID");
                                      flutterTts.setPitch(1.0);
                                      flutterTts.setSpeechRate(0.5);
                                      flutterTts.speak(phrase);
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF448376),
                                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                    child: Text(
                                      phrase,
                                      style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  );
                                }).toList(),
                              ),
                            );
                          },
                        );
                      },
                      icon: const Icon(Icons.chat_bubble_outline, color: Colors.white),
                      label: Text(
                        'Komunikasi Cepat',
                        style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Colors.white,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF448376),
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),

                    const SizedBox(height: 60,),

                  ],
                ),
              ),
            ),
          ),

          Positioned(
            bottom: 80,
            left: 0,
            right: 0,
            child: Image.asset(
              'assets/mulut.png',
              width: 200,
              height: 200,
              fit: BoxFit.contain,
            ),
          ),

          // Tombol kembali
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 30),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  side: const BorderSide(color: Color(0xFF448376), width: 2),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  'Kembali Ke Halaman Sebelumnya',
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF448376),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
