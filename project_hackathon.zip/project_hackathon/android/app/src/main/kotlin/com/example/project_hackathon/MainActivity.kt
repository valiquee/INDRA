package com.example.project_hackathon

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
