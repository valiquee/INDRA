import org.gradle.api.initialization.Settings

plugins.apply("flutter.plugin.platforms.android")

include(":app")